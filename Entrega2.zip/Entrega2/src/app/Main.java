package app;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Main {
	
	public static void main(String[] args) {
		Chrome();
		//Firefox();
		//InternetExplorer();
		}
	private static WebDriver driver= null;
	
	public static void Chrome()	{
		String exePath = "C:\\eclipseWD\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		driver = new ChromeDriver(options);
		driver.get("http://www.fnac.es");
		
		WebElement ventanaCookies =	driver.findElement(By.xpath("/html/body/aside/div/button"));
		if (ventanaCookies != null)	{System.out.println("Detectado caja de cookies");
		ventanaCookies.click();}
		
		
		WebElement cajaBusqueda = driver.findElement(By.id("Fnac_Search"));
					cajaBusqueda.sendKeys("Cafeteras Bosch");
					cajaBusqueda.submit();
			
		WebDriverWait waiting;
			waiting = new WebDriverWait(driver, 10);
			waiting.until( ExpectedConditions.presenceOfElementLocated(
			By.cssSelector(".n2 > li:nth-child(3) > span:nth-child(1)")));
			
			
			
		WebElement element = driver.findElement(By.cssSelector(".n2 >li:nth-child(3) > span:nth-child(1)"));
			if (element != null)
				{ element.click();
				System.out.println("Pulsado sobre cafeteras");}
			
			List<WebElement> listaElementos =
					driver.findElements(By.xpath("//*[contains(@class, 'Article-itemGroup')]"));
					System.out.println("N�mero de elementos de la lista: " + listaElementos.size());
					// Obtener cada uno de los art�culos
					WebElement elementoActual, navegacion;
					int j=1;
					for (int i=0; i<listaElementos.size(); i++)
					{
					elementoActual = listaElementos.get(i);
					navegacion =
					elementoActual.findElement(By.xpath("/html/body/div[4]/div/div[6]/ul/li[" + j +
					"]"+"/div/div[2]/div/p[1]/a" ));
					System.out.println(j + " " + navegacion.getText());
					j++;
					}
		// driver.quit();
				
	
	
	}
	
	
	
		
	
	
	
	
}
