package pizzeria1;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("Pizzeria funcionando")
public class Pizzeria extends ServletProcessApplication {

}
